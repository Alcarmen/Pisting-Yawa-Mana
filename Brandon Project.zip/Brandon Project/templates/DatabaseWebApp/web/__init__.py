from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = '69420 ASDSADSADASDA'
    
    from .login import login
    from .views import views
    from .items import items

    
    app.register_blueprint(views, url_prefix ='/')
    app.register_blueprint(items, url_prefix ='/')
    app.register_blueprint(login, url_prefix ='/')


    return app