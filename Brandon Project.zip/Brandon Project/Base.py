from flask import Flask, render_template,request,url_for,redirect,session,flash
from dbhelper import *
from datetime import datetime

app = Flask(__name__)
app.secret_key= '696969BRANDON696969'

app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "user" in session:
		session.pop("user")
		flash("Logged Out")
	return render_template("login.html",title="Welcome to Brandon's Book Store")

@app.route("/")
def main()->None:
	return render_template("indexs.html",title="Welcome to Brandon's Book Store")


@app.route('/home')
def home():
    if "user" in session and isinstance(session['user'], dict):
        if session['user']['role'] == 'admin':
            return render_template("Home.html")
        
        flash("Unauthorized access")
        return redirect("/User")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Fetch user details based on email and password from the database using your getrecords function
        user = getrecords('customers', email=email, password=password)

        if user and user['active'] == 1:  # Check if user exists and is active
            # Fetch additional user details (such as c_name, c_address) from the database
            user_details = fetch_user_details(email, password)

            if user_details:
                session['user'] = {
                    'user_id': user['c_id'],
                    'c_name': user_details['c_name'],
                    'c_email': user['c_email'],
                    'c_address': user_details['c_address'],
                    'role': user['role']
                }

                if user['role'] == 'admin':
                    return redirect('/home')
                
                return redirect('/User')
            else:
                flash('Error fetching user details.')
                return render_template('login.html')

        else:
            flash('Invalid credentials or inactive account')
            return render_template('login.html')

    return render_template('login.html')



@app.route('/User')
def User():
    if "user" in session and isinstance(session['user'], dict):
        if session['user']['role'] == 'customer':
            items = getall("items")
            return render_template("User_end.html", items=items)
        
        flash("Unauthorized access")
        return redirect("/home")


@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        # Get form data
        c_name, c_email, c_address, password = dict(request.form).values()

        # Check if any field is empty
        if not all([c_name, c_email, c_address, password]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('register'))

        existing_customer = getrecord('customers', c_email=c_email)
        if existing_customer:
            flash('Email already exists. Please use a different email.')
            return redirect(url_for('register'))  

        addrecord('customers', c_name=c_name, c_email=c_email, c_address=c_address, password=password)
        flash('Registered successfully!')
        return redirect(url_for('login'))

    return render_template("register.html", title="Register Page")

    
@app.route('/Custom', methods=['GET', 'POST'])
def Custom():
    if "user" in session and isinstance(session['user'], dict):
        if session['user']['role'] == 'admin':
            # Fetching specific columns from the 'customers' table
            data = get_specific_columns_from_customers_table()

            head = ['ID', 'Name', 'Email', 'Address', 'Password', 'Role', 'Action']

            return render_template("index.html", student=data, header=head)
        else:
            flash("Unauthorized access")
            return redirect("/User")

 
@app.route('/Item')
def Item():
    if "user" in session and isinstance(session['user'], dict):
        if session['user']['role'] == 'admin':
            it = get_specific_columns_from_items_table()  # Retrieve specific columns from items table
            head = ['ID', 'ISBN', 'Title', 'Author', 'Genre', 'Price', 'Quantity', 'Type', 'Action']
            columns_to_display = ['ID', 'ISBN', 'Title', 'Author', 'Genre', 'Price', 'Quantity', 'Type', 'Action']
            # Make sure to adjust 'ID' to match the actual primary key or identifier column name in the 'items' table

            return render_template("itemindex.html", item=it, header=head, columns_to_display=columns_to_display)
        flash("Unauthorized access")
        return redirect("/User")
 
@app.route('/create', methods=['GET','POST'])
def create():
    if request.method == 'POST':
        c_name,c_email,c_address=dict(request.form).values()

        if not all([c_name, c_email, c_address]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('create'))

        existing_customer = getrecord('customers', c_email=c_email)
        if existing_customer:
            flash('Email already exists. Please use a different email.')
            return redirect(url_for('create'))  
        else:
            flash('Customer has been added succesfully!')
            addrecord('customers',c_name=c_name, c_email=c_email, c_address=c_address)
            return redirect(url_for('Custom'))
    return render_template("Create.html")

@app.route('/createitem', methods=['GET', 'POST'])
def createitem():
    if request.method == 'POST':
        ISBN, title, author, genre, price, i_type,qty = dict(request.form).values()

        if not all([ISBN, title, author, genre, price, i_type,qty]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('createitem'))
        
        existing_item = getrecord('items', ISBN=ISBN)
        
        if existing_item:
            flash('Error: ISBN already exists.')
            return redirect(url_for('createitem'))
        else:
            flash('Item has been added succesfully!')
            addrecord('items', ISBN=ISBN, title=title, author=author, genre=genre, price=price, i_type=i_type,qty=qty)
            return redirect(url_for('Item'))
            
    return render_template("Item-Create.html")

@app.route('/update/<c_id>', methods=['GET','POST'])
def update(c_id):
    if request.method == 'POST':
        c_name,c_email,c_address=dict(request.form).values()
        updaterecord('customers',c_id=c_id,c_name=c_name, c_email=c_email, c_address=c_address)
        return redirect(url_for('Custom'))
       
    customer = None
    customers = getrecord('customers',c_id=c_id)
    if len(customers) > 0:
        customer = customers[0]
    return render_template("Update.html",customer=customer)

@app.route('/delete_cust/<c_id>',methods=['GET'])
def delete_cust(c_id):
    if request.method == 'GET':
        deleterecord('customers',c_id=c_id)
        return redirect(url_for("Custom"))

#-------ITEMS---------
@app.route('/update_item/<i_id>', methods=['GET', 'POST'])
def update_item(i_id):
    item = None
    items = getrecord('items', i_id=i_id)
    
    if len(items) > 0:
        item = items[0]
    
    if request.method == 'POST':
        form_data = request.form
        
        ISBN = form_data.get('ISBN')
        title = form_data.get('title')
        author = form_data.get('author')
        genre = form_data.get('genre')
        price = form_data.get('price')  # Retrieve price from form data
        i_type = form_data.get('i_type')
        qty = form_data.get('qty')
        
        if int(qty) < 0:
            flash("Quantity cannot be lesser than 0!")
            return redirect(url_for('Item'))
        
        # Convert qty to 'Out of Stock' if it's 0
        if int(qty) == 0:
            qty = 'Out of Stock'
        
        # Check if price is a valid number or not
        try:
            price = float(price)
        except ValueError:
            flash("Price should be a valid number!")
            return redirect(url_for('Item'))
        
        # Update record with the new values
        updaterecord('items', i_id=i_id, ISBN=ISBN, title=title, author=author, genre=genre, price=price, i_type=i_type, qty=qty)
        
        return redirect(url_for('Item'))
       
    return render_template("Item-Update.html", item=item)

@app.route('/delete_item/<i_id>',methods=['GET'])
def delete_item(i_id):
    if request.method == 'GET':
        deleterecord('items',i_id=i_id)
        return redirect(url_for("Item"))
        
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        search_query = request.form.get('search_query')
        print("Search Query:", search_query)  # Check if the query is captured correctly

        results = searchrecord('customers', search_query)
        print("Results:", results)  # Check the results obtained

        if not results:
            flash("No result found!")
            return render_template("Searched.html", error_message="No result found!")  # Redirect to a route displaying the flashed message

        return render_template("Searched.html", results=results)

    return redirect(url_for("Custom"))



@app.route('/search_item', methods=['GET', 'POST'])
def search_item():
    if request.method == 'POST':
        item_searched = request.form.get('item_searched')
        print("Search Query:", item_searched)  # Check if the query is captured correctly

        output = itemrecord('items', item_searched)
        print("Results:", output)  # Check the results obtained

        if not output:
            flash("No result found!")
            return render_template("Item-Search.html", error_message="No result found!")  # Create a NoResults.html template

        return render_template("Item-Search.html", output=output)

    return redirect(url_for("Item"))

def get_count(table, column='*'):
    db = db_connect()
    cursor = db.cursor()
    cursor.execute(f"SELECT COUNT({column}) FROM {table}")
    count = cursor.fetchone()[0]
    db.close()
    return count

@app.route('/display')
def display_column_count():
    table_name = 'customers'  # Replace with your actual table name
    column_count = get_count(table_name)
    return render_template('count.html', column_count=column_count)

def get_user_id(c_id):
    sql = """
    SELECT user_id 
    FROM customers 
    WHERE c_id = %s AND active = 1
    """
    result = getProcess(sql, (c_id,))
    return result[0]['user_id'] if (result and result[0].get('user_id')) else None

def get_cart_items_with_c_id(user_id):
    sql = """
    SELECT cart.*, customers.c_id
    FROM cart
    JOIN customers ON cart.user_id = customers.user_id
    WHERE cart.user_id = %s
    """
    result = getProcess(sql, (user_id,))
    return result if result else []

@app.route('/add_to_cart/<isbn>', methods=['POST'])
def add_to_cart(isbn):
    if 'user' in session:
        item = get_item_details(isbn)

        if item:
            try:
                quantity = int(request.form.get('qty', 1))
                if quantity <= 0:
                    raise ValueError("Invalid quantity")

                if item.get('qty', 0) >= quantity:
                    cart = session.get('cart', [])

                    cart.append({
                        'ISBN': item['ISBN'],
                        'title': item['title'],
                        'price': item['price'],
                        'quantity': quantity,
                    })

                    flash(f'{quantity} x {item["title"]} added to cart!')
                    session['added_item'] = {'item': item, 'quantity': quantity}
                    session['cart'] = cart  # Store cart items in session

                    return redirect('/view_cart')
                else:
                    flash('Error: Out of stock or invalid quantity')
            except ValueError as e:
                flash(f'Error: {e}')
        else:
            flash('Item not found!')
    else:
        flash('Please log in to add items to your cart.')

    # Redirect to a suitable page for the user to continue shopping
    return redirect('/catalog')


@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'user' in session and 'cart' in session and session['cart']:
        user = session.get('user')

        if isinstance(user, dict) and user.get('user_id'):
            user_id = user['user_id']
            cart_items = session['cart']

            # Save the cart items to the database if not saved already
            save_cart_to_database(user_id, cart_items)

            # Proceed with checkout operations
            if perform_checkout_operations(user_id, cart_items):
                flash('Checkout successful!')

                # Fetch user details and checked-out items from the database
                user_profile = get_user_profile(user_id)
                checked_out_items = fetch_checked_out_items_from_database(user_id)

                # Pass the checked-out items to the template for rendering
                return render_template('checkout.html', user=user_profile, checked_out_items=checked_out_items)
            else:
                flash('Error during checkout. Please try again.')
                return redirect('/User')
        else:
            flash('Invalid user information found.')
            return redirect('/User')
    else:
        flash('Your cart is empty or you are not logged in.')
        return redirect('/User')


def perform_checkout_operations(user_id, cart_items):
    try:
        checkout_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        for item in cart_items:
            item_id = get_item_id_from_isbn(item['ISBN'])  # Fetch item_id from the ISBN
            
            if item_id:
                quantity = item.get('quantity', 0)
                
                # Save checkout record for each item in the cart
                save_checkout_to_database(user_id, item_id, quantity, checkout_date)
                
                # Update item quantities in the database after checkout
                update_item_qty(item['ISBN'], max(0, int(item['qty']) - quantity))  # Update item quantity after checkout
        
        # Clear the cart in the session after saving to the database
        session.pop('cart', None)
        
        flash('Checkout successful!')
        return redirect('/User')  # Redirect to a suitable page after successful checkout
    except Exception as e:
        print(f"Checkout error: {str(e)}")
        flash('Error during checkout. Please try again.')
        return redirect('/User')

        
def fetch_checked_out_items_from_database(user_id):
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)
        sql = """
        SELECT checkout_records.*, items.item_id, items.item_name, items.price, items.checkout_time
        FROM checkout_records 
        JOIN items ON checkout_records.item_id = items.item_id 
        WHERE checkout_records.user_id = %s
        """
        cursor.execute(sql, (user_id,))
        checkout_records = cursor.fetchall()

        checked_out_items = []
        for record in checkout_records:
            checked_out_items.append({
                'item_id': record['item_id'],
                'item_name': record['item_name'],
                'price': record['price'],
                'quantity': record['quantity'],
                'checkout_time': record['checkout_time']
                # Add more item details if needed
            })

        db.commit()  # Commit changes after executing the query
        return checked_out_items
    except Exception as e:
        print(f"Error fetching checked-out items: {str(e)}")
        return []
    finally:
        cursor.close()
        db.close()
@app.route('/checkout_history')
def checkout_history():
    # Retrieve checkout history from the database
    checkout_records = get_checkout_history_from_database()

    return render_template('Checkoutlist.html', checkout_records=checkout_records)

@app.route('/view_cart')
def view_cart():
    if "user" in session and isinstance(session['user'], dict):
        if session['user']['role'] == 'customer':
            cart = session.get('cart', [])
            added_item = session.pop('added_item', None)
            return render_template('cart.html', cart=cart, added_item=added_item)
        else:
            flash("Unauthorized access")
            return redirect("/home")
@app.route('/Cart')
def Cart():
    c_id = session.get('c_id')  # Retrieve c_id from the session or use your logic to get it
    user_id = get_user_id(c_id)
    
    if user_id:
        cart_items = get_cart_items_with_c_id(user_id)  # Fetch cart items for the user

        if cart_items:
            return render_template('cart.html', cart_items=cart_items)
        else:
            flash('Cart is empty!')
    else:
        flash('User not found or not logged in!')

    return redirect('/user')

@app.route('/checkout_details/<user_id>', methods=['GET'])
def checkout_details(user_id):
    checked_out_items = fetch_checked_out_items_from_database(user_id)

    return render_template('checkout.html', checked_out_items=checked_out_items)

def fetch_checked_out_items_from_database(user_id):
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)
        sql = """
        SELECT checkout_records.*, items.ISBN as item_id, items.title as item_name, items.price, items.qty, items.i_type
        FROM checkout_records 
        JOIN items ON checkout_records.item_id = items.i_id
        WHERE checkout_records.user_id = %s
        """
        cursor.execute(sql, (user_id,))
        checkout_records = cursor.fetchall()

        checked_out_items = []
        for record in checkout_records:
            checked_out_items.append({
                'item_id': record['item_id'],
                'item_name': record['item_name'],
                'price': record['price'],
                'quantity': record['quantity'],
                'i_type': record['i_type']  # Include 'i_type' in the dictionary
            })

        db.commit()  # Commit changes after executing the query
        return checked_out_items
    except Exception as e:
        print(f"Error fetching checked-out items: {str(e)}")
        return []
    finally:
        cursor.close()
        db.close()


def perform_checkout_operations(user_id, cart_items):
    try:
        checkout_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        for item in cart_items:
            # Fetch item_id using ISBN before saving checkout records
            item_details = fetch_item_details_from_database(item['ISBN'])
            if item_details:
                item_id = item_details['i_id']
                quantity = item['quantity']
                
                save_checkout_to_database(user_id, item_id, quantity, checkout_date)
                
                # Update item quantities in the database after checkout
                new_quantity = item_details['qty'] - quantity
                update_item_qty(item['ISBN'], new_quantity)
        
        # Clear the cart in the session after saving to the database
        session.pop('cart', None)
        return True
    except Exception as e:
        print(f"Checkout error: {str(e)}")
        return False

@app.route('/admin/checkout_details')
def admin_checkout_details():
    if "user" in session and session['user']['role'] == 'admin':
        # Fetch checkout details of all users from the database
        checkout_details = fetch_all_checkout_details()
        return render_template('admin_checkout_details.html', checkout_details=checkout_details)
    else:
        flash("Unauthorized access")
        return redirect("/home")

def fetch_all_checkout_details():
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)
        sql = """
        SELECT checkout_records.*, customers.c_id, customers.c_name, items.item_id, items.title AS item_title, items.price, items.i_type
        FROM checkout_records 
        JOIN items ON checkout_records.item_id = items.i_id
        JOIN customers ON checkout_records.user_id = customers.c_id
        """
        cursor.execute(sql)
        checkout_records = cursor.fetchall()

        db.commit()
        return checkout_records
    except Exception as e:
        print(f"Error fetching checkout details: {str(e)}")
        return []
    finally:
        cursor.close()
        db.close()

        
if __name__=='__main__':
    
    app.run(debug=True)