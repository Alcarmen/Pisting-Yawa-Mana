"""
	Python Database helper
"""
from mysql.connector import connect

def db_connect()->object:
    return connect(
        host="localhost",
        user="root",
        password="",
        database="customer"
    )
    
def doProcess(sql: str, params: tuple = ()) -> bool:
    db: object = db_connect()
    cursor: object = db.cursor()
    cursor.execute(sql, params)
    db.commit()
    return True if cursor.rowcount > 0 else False

def getProcess(sql: str, params: tuple = ()) -> list:
    db = db_connect()
    cursor = db.cursor(dictionary=True)
    cursor.execute(sql, params)
    return cursor.fetchall()

def getrecords(table: str, email: str, password: str) -> dict:
    sql = f"SELECT * FROM `{table}` WHERE `c_email` = '{email}' AND `password` = '{password}' AND `active` = 1"
    user = getProcess(sql)

    if user:
        return user[0]
    else:
        return None
def fetch_item_details_from_database(isbn):
    try:
        sql = "SELECT * FROM items WHERE ISBN = %s"
        item = getProcess(sql, (isbn,))
        return item[0] if item else None
    except Exception as e:
        print(f"Error fetching item details from the database: {str(e)}")
        return None

def update_item_quantity_in_database(isbn, new_quantity):
    try:
        sql = "UPDATE items SET qty = %s WHERE ISBN = %s"
        doProcess(sql, (new_quantity, isbn))
    except Exception as e:
        print(f"Error updating item quantity: {str(e)}")

def update_item_quantities(cart_items):
    try:
        for item in cart_items:
            item_details = fetch_item_details_from_database(item['ISBN'])

            if item_details:
                current_quantity = item_details['qty']
                new_quantity = current_quantity - item['quantity']
                update_item_quantity_in_database(item['ISBN'], new_quantity)
    except Exception as e:
        print(f"Error updating item quantities: {str(e)}")

def save_cart_to_database(user_id, cart_items):
    for item in cart_items:
        sql = "INSERT INTO cart (user_id, item_id, quantity) VALUES (%s, %s, %s)"
        values = (user_id, item.get('item_id'), item.get('quantity'))  # Use get method to avoid KeyError
        doProcess(sql, values)

def get_item_details(isbn: str) -> dict:
    try:
        sql = "SELECT * FROM `items` WHERE `ISBN` = %s AND `active` = 1"
        item = getProcess(sql, (isbn,))

        if item:
            return item[0]
        else:
            return None
    except Exception as e:
        print(f"Error fetching item details: {str(e)}")
        return None
    
def update_item_qty(isbn, new_qty):
    sql = "UPDATE items SET qty = %s WHERE ISBN = %s"
    params = (new_qty, isbn)
    doProcess(sql, params)

def getall(table:str)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1"
    return getProcess(sql)

def get_specific_columns_from_customers_table() -> list:
    try:
        sql = "SELECT c_id, c_name, c_email, c_address, role, password FROM customers WHERE active = 1"
        return getProcess(sql)
    except Exception as e:
        print(f"Error fetching specific columns from customers table: {str(e)}")
        return []

def get_specific_columns_from_items_table() -> list:
    try:
        sql = "SELECT i_id, ISBN, title, author, genre, price, qty,  i_type FROM items WHERE active = 1"
        return getProcess(sql)
    except Exception as e:
        print(f"Error fetching specific columns from items table: {str(e)}")
        return []

def getrecord(table:str,**kwargs)->list:
    params:list = list(kwargs.items())
    flds:list = list(params[0])
    sql:str = f"SELECT * FROM `{table}` WHERE `{flds[0]}`='{flds[1]}'"
    return getProcess(sql)
    
def addrecord(table:str,**kwargs)->bool:
    flds:list = list(kwargs.keys())
    vals:list = list(kwargs.values())
    fld:str = "`,`".join(flds)
    val:str = "','".join(vals)
    sql:str = f"INSERT INTO `{table}`(`{fld}`) values('{val}')"
    print(sql)
    return doProcess(sql)

def addrecords(table, **kwargs):
    columns = ', '.join(kwargs.keys())
    values_template = ', '.join(['%s'] * len(kwargs))
    values = tuple(kwargs.values())

    sql = f"INSERT INTO {table} ({columns}) VALUES ({values_template})"
    return doProcess(sql, values)

    
def updaterecord(table:str,**kwargs)->bool:
    flds:list = list(kwargs.keys())
    vals:list = list(kwargs.values())
    fld:list = []
    for i in range(1,len(flds)):
        fld.append(f"`{flds[i]}`='{vals[i]}'")
    params:str = ",".join(fld)
    sql:str = f"UPDATE `{table}` SET {params} WHERE `{flds[0]}`='{vals[0]}'"
    print(sql)
    return doProcess(sql)
    
def deleterecord(table:str,**kwargs)->bool:
    params:list = list(kwargs.items())
    flds:list = list(params[0])
    sql:str = f"UPDATE `{table}` SET active = 0 WHERE `{flds[0]}`='{flds[1]}'"
    return doProcess(sql)
    
def searchrecord(table:str,search_term)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1 AND (c_name LIKE '%{search_term}%' OR c_email LIKE '%{search_term}%' OR c_address LIKE '%{search_term}%')"
    return getProcess(sql)
def itemrecord(table:str,search_item)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1 AND (ISBN LIKE '%{search_item}%' OR title LIKE '%{search_item}%' OR author LIKE '%{search_item}%' OR genre LIKE '%{search_item}%' OR price LIKE '%{search_item}%' OR i_type LIKE '%{search_item}%')"
    return getProcess(sql)

def getrecords(table:str, email:str, password:str) -> dict:
    # Fetch user details based on email and password from the database
    sql = f"SELECT * FROM `{table}` WHERE `c_email` = '{email}' AND `password` = '{password}' AND `active` = 1"
    user = getProcess(sql)
    
    if user:
        return user[0]  # Return the first user found
    else:
        return None
# Function to save checkout details to the database
def save_checkout_to_database(user_id, item_id, quantity, checkout_date):
    try:
        db = db_connect()
        cursor = db.cursor()

        sql = "INSERT INTO checkout_records (user_id, item_id, quantity, checkout_date) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql, (user_id, item_id, quantity, checkout_date))

        db.commit()
        return True
    except Exception as e:
        print(f"Error during checkout: {str(e)}")
        db.rollback()
        return False
    finally:
        cursor.close()
        db.close()



    
# Function to retrieve checkout history from the database
def get_checkout_history_from_database():
    sql = "SELECT * FROM checkout_records"

    db = db_connect()
    cursor = db.cursor(dictionary=True)

    try:
        cursor.execute(sql)
        checkout_records = cursor.fetchall()
        return checkout_records
    except Exception as e:
        print(f"Error retrieving checkout history: {e}")
        return []
    finally:
        cursor.close()
        db.close()

def get_user_profile(user_id):
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)

        sql = "SELECT * FROM `customers` WHERE `c_id` = %s AND `active` = 1"  # Updated table name
        cursor.execute(sql, (user_id,))
        user_profile = cursor.fetchone()

        return user_profile
    except Exception as e:
        print(f"Error fetching user profile: {str(e)}")
        return None
    finally:
        cursor.close()
        db.close()

def get_checkout_details(user_id):
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)

        sql = "SELECT * FROM checkout_records WHERE user_id = %s"  # Corrected column name
        cursor.execute(sql, (user_id,))
        checkout_details = cursor.fetchall()

        return checkout_details
    except Exception as e:
        print(f"Error fetching checkout details: {str(e)}")
        return None
    finally:
        cursor.close()
        db.close()

def fetch_user_details(email, password):
    try:
        db = db_connect()
        cursor = db.cursor(dictionary=True)
        sql = "SELECT c_name, c_email, c_address FROM `customers` WHERE `c_email` = %s AND `password` = %s AND `active` = 1"
        cursor.execute(sql, (email, password))
        user_details = cursor.fetchone()
        db.commit()  # Commit changes after executing the query
        return user_details
    except Exception as e:
        print(f"Error fetching user details: {str(e)}")
        return None
    finally:
        cursor.close()
        db.close()
        
def add_item_id_column():
    try:
        sql = "ALTER TABLE cart ADD COLUMN item_id INT"  # Adjust data type as needed
        doProcess(sql)
        print("Column 'item_id' added successfully.")
    except Exception as e:
        print(f"Error adding column: {str(e)}")

def get_item_id_from_isbn(isbn):
    try:
        sql = "SELECT i_id FROM items WHERE ISBN = %s"
        result = getProcess(sql, (isbn,))
        return result[0]['i_id'] if result else None
    except Exception as e:
        print(f"Error fetching item ID for ISBN {isbn}: {str(e)}")
        return None
def fetch_data_for_customer(user_id):
    try:
        sql = "SELECT * FROM checkout_records WHERE user_id = %s"  # Update the query to retrieve checkout records for a specific user
        result = getProcess(sql, (user_id,))
        return result
    except Exception as e:
        print(f"Error fetching data for customer: {str(e)}")
        return None